CREATE TABLE submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role ENUM('Student', 'Faculty', 'Library Staff') NOT NULL,
    title VARCHAR(255) NOT NULL,
    type ENUM('eBook', 'Research Paper', 'Multimedia', 'Others') NOT NULL,
    author VARCHAR(255) NOT NULL,
    publication_date DATE NOT NULL,
    description TEXT NOT NULL,
    keywords TEXT,
    file_url VARCHAR(2083) NOT NULL,
    access_level ENUM('Public', 'Restricted', 'Private') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);